CREATE VIEW user_permission_view AS
  (SELECT
     `u`.`id`                             AS `user_id`,
     `u`.`user_name`                      AS `user_name`,
     `r`.`project_id`                     AS `project_id`,
     `r`.`role_name`                      AS `role_name`,
     `r`.`id`                             AS `role_id`,
     `p`.`id`                             AS `permission_id`,
     `p`.`permission_name`                AS `permission_name`,
     `p`.`permission_name_english`        AS `permission_name_english`,
     `p`.`permission_description`         AS `permission_description`,
     `p`.`permission_description_english` AS `permission_description_english`,
     `p`.`permission_action`              AS `permission_action`,
     `p`.`permission_type`                AS `permission_type`,
     `p`.`parent_id`                      AS `permission_parent_id`
   FROM ((((`artemis`.`user` `u`
     JOIN `artemis`.`user_role` `ur` ON ((`u`.`id` = `ur`.`user_id`))) LEFT JOIN `artemis`.`role` `r`
       ON ((`ur`.`role_id` = `r`.`id`))) LEFT JOIN `artemis`.`role_permission` `rp`
       ON ((`r`.`id` = `rp`.`role_id`))) LEFT JOIN `artemis`.`permission` `p` ON ((`rp`.`permission_id` = `p`.`id`)))
   WHERE (`p`.`status` = 1));

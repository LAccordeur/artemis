CREATE VIEW animal_house_building_detail_view AS
  SELECT
    `artemis`.`animal`.`id`                        AS `animal_id`,
    `artemis`.`animal`.`user_id`                   AS `user_id`,
    `artemis`.`animal`.`project_id`                AS `project_id`,
    `artemis`.`animal`.`house`                     AS `house`,
    `artemis`.`animal`.`code`                      AS `code`,
    `artemis`.`animal`.`id_number`                 AS `id_number`,
    `artemis`.`animal`.`treatment`                 AS `treatment`,
    `artemis`.`animal`.`replicate`                 AS `replicate`,
    `artemis`.`animal_house_relation`.`start_time` AS `start_time`,
    `artemis`.`animal_house_relation`.`end_time`   AS `end_time`,
    `artemis`.`animal_house`.`id`                  AS `house_id`,
    `artemis`.`animal_house`.`house_code`          AS `house_code`,
    `artemis`.`animal_building`.`id`               AS `building_id`,
    `artemis`.`animal_building`.`building_code`    AS `building_code`,
    `artemis`.`animal_building`.`house_number`     AS `house_number`
  FROM (((`artemis`.`animal`
    LEFT JOIN `artemis`.`animal_house_relation`
      ON ((`artemis`.`animal_house_relation`.`animal_id` = `artemis`.`animal`.`id`))) LEFT JOIN `artemis`.`animal_house`
      ON ((`artemis`.`animal_house_relation`.`house_id` = `artemis`.`animal_house`.`id`))) LEFT JOIN
    `artemis`.`animal_building` ON ((`artemis`.`animal_house`.`building_id` = `artemis`.`animal_building`.`id`)));

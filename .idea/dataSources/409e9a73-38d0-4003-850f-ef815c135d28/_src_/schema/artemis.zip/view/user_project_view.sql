CREATE VIEW user_project_view AS
  SELECT
    `artemis`.`project`.`id`                 AS `project_id`,
    `artemis`.`project`.`project_name`       AS `project_name`,
    `artemis`.`project`.`project_admin_id`   AS `project_admin_id`,
    `artemis`.`project`.`project_admin_name` AS `project_admin_name`,
    `artemis`.`user_project`.`user_id`       AS `user_id`,
    `artemis`.`user`.`user_name`             AS `user_name`,
    `artemis`.`role`.`id`                    AS `role_id`,
    `artemis`.`role`.`role_name`             AS `role_name`,
    `artemis`.`project`.`create_time`        AS `create_time`
  FROM ((((`artemis`.`project`
    JOIN `artemis`.`user_project` ON ((`artemis`.`user_project`.`project_id` = `artemis`.`project`.`id`))) JOIN
    `artemis`.`user` ON ((`artemis`.`user_project`.`user_id` = `artemis`.`user`.`id`))) JOIN `artemis`.`user_role`
      ON ((`artemis`.`user`.`id` = `artemis`.`user_role`.`user_id`))) JOIN `artemis`.`role`
      ON (((`artemis`.`project`.`id` = `artemis`.`role`.`project_id`) AND
           (`artemis`.`user_role`.`role_id` = `artemis`.`role`.`id`))));

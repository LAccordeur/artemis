CREATE VIEW role_permission_view AS
  SELECT
    `artemis`.`role`.`id`                                                                 AS `role_id`,
    `artemis`.`role`.`role_name`                                                          AS `role_name`,
    `artemis`.`permission`.`id`                                                           AS `permission_id`,
    `artemis`.`permission`.`permission_name`                                              AS `permission_name`,
    `artemis`.`permission`.`permission_name_english`                                      AS `permission_name_english`,
    (SELECT count(0)
     FROM `artemis`.`role_permission`
     WHERE ((`artemis`.`role_permission`.`role_id` = `artemis`.`role`.`id`) AND
            (`artemis`.`role_permission`.`permission_id` = `artemis`.`permission`.`id`))) AS `status`
  FROM `artemis`.`role`
    JOIN `artemis`.`permission`
  WHERE (`artemis`.`permission`.`status` = 1);

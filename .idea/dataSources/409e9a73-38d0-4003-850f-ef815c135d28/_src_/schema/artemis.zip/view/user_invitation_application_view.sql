CREATE VIEW user_invitation_application_view AS
  SELECT
    `artemis`.`user`.`id`                    AS `user_id`,
    `artemis`.`user`.`user_name`             AS `user_name`,
    `artemis`.`project`.`id`                 AS `project_id`,
    `artemis`.`project`.`project_name`       AS `project_name`,
    `artemis`.`user_project`.`status`        AS `status`,
    `artemis`.`user_project`.`join_type`     AS `join_type`,
    `artemis`.`user`.`university`            AS `university`,
    `artemis`.`user`.`user_identity`         AS `user_identity`,
    `artemis`.`user`.`user_email`            AS `user_email`,
    `artemis`.`project`.`project_intro`      AS `project_intro`,
    `artemis`.`project`.`project_admin_name` AS `project_admin_name`,
    `artemis`.`user_project`.`create_time`   AS `create_time`
  FROM ((`artemis`.`user`
    JOIN `artemis`.`user_project` ON ((`artemis`.`user_project`.`user_id` = `artemis`.`user`.`id`))) JOIN
    `artemis`.`project` ON ((`artemis`.`user_project`.`project_id` = `artemis`.`project`.`id`)));

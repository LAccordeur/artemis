CREATE VIEW animal_formulation_detail_view AS
  SELECT
    `artemis`.`animal`.`id`                              AS `animal_id`,
    `artemis`.`animal`.`user_id`                         AS `user_id`,
    `artemis`.`animal`.`project_id`                      AS `project_id`,
    `artemis`.`animal`.`animal_init_weight`              AS `animal_init_weight`,
    `artemis`.`animal`.`house`                           AS `house`,
    `artemis`.`animal`.`code`                            AS `code`,
    `artemis`.`animal`.`id_number`                       AS `id_number`,
    `artemis`.`animal`.`treatment`                       AS `treatment`,
    `artemis`.`animal`.`replicate`                       AS `replicate`,
    `artemis`.`formulation_animal_relation`.`start_time` AS `start_time`,
    `artemis`.`formulation_animal_relation`.`end__time`  AS `end__time`,
    `artemis`.`formulation`.`id`                         AS `formulation_id`,
    `artemis`.`formulation`.`formulation_code`           AS `formulation_code`,
    `artemis`.`formulation`.`formulation_name`           AS `formulation_name`,
    `artemis`.`formulation`.`formulation_material_cost`  AS `formulation_material_cost`
  FROM ((`artemis`.`animal`
    LEFT JOIN `artemis`.`formulation_animal_relation`
      ON ((`artemis`.`formulation_animal_relation`.`animal_id` = `artemis`.`animal`.`id`))) LEFT JOIN
    `artemis`.`formulation`
      ON ((`artemis`.`formulation_animal_relation`.`formulation_id` = `artemis`.`formulation`.`id`)));

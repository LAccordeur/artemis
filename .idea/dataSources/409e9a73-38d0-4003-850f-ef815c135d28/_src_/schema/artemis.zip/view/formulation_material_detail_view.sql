CREATE VIEW formulation_material_detail_view AS
  SELECT
    `artemis`.`formulation`.`id`                               AS `formulation_id`,
    `artemis`.`formulation`.`user_id`                          AS `user_id`,
    `artemis`.`formulation`.`project_id`                       AS `project_id`,
    `artemis`.`formulation`.`formulation_code`                 AS `formulation_code`,
    `artemis`.`formulation`.`formulation_name`                 AS `formulation_name`,
    `artemis`.`formulation`.`formulation_material_cost`        AS `formulation_material_cost`,
    `artemis`.`formulation_material_relation`.`id`             AS `formulation_material_relation_id`,
    `artemis`.`formulation_material_relation`.`material_id`    AS `material_id`,
    `artemis`.`formulation_material_relation`.`material_name`  AS `material_name`,
    `artemis`.`formulation_material_relation`.`material_price` AS `material_price`,
    `artemis`.`formulation_material_relation`.`optimal_ratio`  AS `optimal_ratio`,
    `artemis`.`formulation_material_relation`.`ponderance_ton` AS `ponderance_ton`
  FROM (`artemis`.`formulation`
    LEFT JOIN `artemis`.`formulation_material_relation`
      ON ((`artemis`.`formulation_material_relation`.`formulation_id` = `artemis`.`formulation`.`id`)));
